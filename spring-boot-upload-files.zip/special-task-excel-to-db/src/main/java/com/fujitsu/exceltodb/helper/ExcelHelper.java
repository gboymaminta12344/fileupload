package com.fujitsu.exceltodb.helper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.fujitsu.exceltodb.model.Users;

public class ExcelHelper {
	public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	static String[] HEADERs = { "user_id", "last_name", "first_name", "middle_name", "email", "position_id",
			"department_id", "role_id" };
	static String SHEET = "Users";

	public static boolean hasExcelFormat(MultipartFile file) {

		if (!TYPE.equals(file.getContentType())) {
			return false;
		}

		return true;
	}

	public static ByteArrayInputStream usersToExcel(List<Users> users) {

		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet(SHEET);

			// Header
			Row headerRow = sheet.createRow(0);

			for (int col = 0; col < HEADERs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(HEADERs[col]);
			}

			int rowIdx = 1;
			for (Users user : users) {
				Row row = sheet.createRow(rowIdx++);

				row.createCell(0).setCellValue(user.getUserId());
				row.createCell(1).setCellValue(user.getLastName());
				row.createCell(2).setCellValue(user.getFirstName());
				row.createCell(3).setCellValue(user.getMiddleName());
				row.createCell(4).setCellValue(user.getEmailAddress());
				row.createCell(5).setCellValue(user.getPositionId());
				row.createCell(6).setCellValue(user.getDepartmentId());
				row.createCell(7).setCellValue(user.getRoleId());
			}

			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (IOException e) {
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}
	}

	// excel to database users

	public static List<Users> excelToUsers(InputStream is) {
		try {
			Workbook workbook = new XSSFWorkbook(is);

			Sheet sheet = workbook.getSheet(SHEET);

			Iterator<Row> rows = sheet.iterator();

			List<Users> users = new ArrayList<Users>();

			int rowNumber = 0;
			while (rows.hasNext()) {
				Row currentRow = rows.next();

				// skip header
				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}

				Iterator<Cell> cellsInRow = currentRow.iterator();

				Users user = new Users();

				int cellIdx = 0;
				while (cellsInRow.hasNext()) {
					Cell currentCell = cellsInRow.next();

					switch (cellIdx) {
					case 0:

						user.setUserId(currentCell.getStringCellValue());
						break;
					case 1:
						user.setLastName(currentCell.getStringCellValue());
						break;

					case 2:
						user.setFirstName(currentCell.getStringCellValue());
						break;

					case 3:
						user.setMiddleName(currentCell.getStringCellValue());
						break;
					case 4:
						user.setEmailAddress(currentCell.getStringCellValue());
						break;
					case 5:
						user.setPositionId((int) currentCell.getNumericCellValue());
						break;
					case 6:
						user.setDepartmentId((int) currentCell.getNumericCellValue());
						break;
					case 7:
						user.setRoleId((int) currentCell.getNumericCellValue());
						break;

					default:
						break;
					}

					cellIdx++;
				}

				users.add(user);

			}

			workbook.close();

			return users;
		} catch (IOException e) {
			throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
		}
	}
}
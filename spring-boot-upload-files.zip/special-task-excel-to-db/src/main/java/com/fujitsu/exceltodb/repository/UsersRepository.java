package com.fujitsu.exceltodb.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fujitsu.exceltodb.model.Users;

public interface UsersRepository extends JpaRepository<Users,String> {

}

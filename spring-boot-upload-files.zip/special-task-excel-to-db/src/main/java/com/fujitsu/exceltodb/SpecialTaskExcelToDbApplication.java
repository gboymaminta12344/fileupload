package com.fujitsu.exceltodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpecialTaskExcelToDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpecialTaskExcelToDbApplication.class, args);
	}

}

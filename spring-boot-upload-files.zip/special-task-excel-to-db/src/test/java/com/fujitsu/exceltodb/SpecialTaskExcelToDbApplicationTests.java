package com.fujitsu.exceltodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpecialTaskExcelToDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
